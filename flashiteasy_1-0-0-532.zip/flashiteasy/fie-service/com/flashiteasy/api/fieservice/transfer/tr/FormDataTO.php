<?php
/*
 * Created on 7 avr. 10
 *
 * To change the template for this generated file go to
 * Window - Preferences - PHPeclipse - PHP - Code Templates
 */
//echo $_SERVER['SCRIPT_FILENAME'];
 class FormDataTO extends TransferObject
 {
  
    var $_explicitType = "com.flashiteasy.api.fieservice.transfer.tr.FormDataTO";	
  	public $phpFilePath ;
	public $formData ;
	public $success;
  	
 }
?>